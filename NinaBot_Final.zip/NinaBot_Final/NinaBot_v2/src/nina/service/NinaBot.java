package nina.service;
import nina.model.NinaModel;
import nina.view.NinaView;

/**
 * @author Rafael Papa
 *
 */

public class NinaBot {

	public static void main(String[] args) {
		NinaModel theModel = new NinaModel();
		NinaView theView = new NinaView(theModel);

		// attach the bot view as a listener
		theModel.addChangeListener(theView);
	}
}