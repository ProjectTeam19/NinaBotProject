package nina.view;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.logging.LogManager;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import com.ibm.watson.developer_cloud.assistant.v2.Assistant;
import com.ibm.watson.developer_cloud.assistant.v2.model.CreateSessionOptions;
import com.ibm.watson.developer_cloud.assistant.v2.model.DialogRuntimeResponseGeneric;
import com.ibm.watson.developer_cloud.assistant.v2.model.MessageInput;
import com.ibm.watson.developer_cloud.assistant.v2.model.MessageOptions;
import com.ibm.watson.developer_cloud.assistant.v2.model.MessageResponse;
import com.ibm.watson.developer_cloud.assistant.v2.model.SessionResponse;
import com.ibm.watson.developer_cloud.service.security.IamOptions;

import nina.model.NinaModel;


/**
 * @author Rafael Papa
 *
 */
public class NinaView implements ChangeListener {

	public NinaView(NinaModel theModel) {
		// TODO Auto-generated constructor stub
		this.theModel = theModel;

		JPanel appPanel = new JPanel();

		JScrollPane scroll = new JScrollPane(
				dialogMonitor, 
				JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_NEVER
		);
		
		// ------------------------------------------------------------------
		// avoid the user type inside the dialog
		dialogMonitor.setEditable(false);
		
		dialogMonitor.setFont(new Font("Serif", Font.ITALIC, 14));
		dialogMonitor.setLineWrap(true);
		dialogMonitor.setWrapStyleWord(true);
		
		// ------------------------------------------------------------------
		// attach listeners
		// add the listener to inputText
		inputText.addKeyListener(new 
			KeyAdapter() {
				  public void keyPressed(KeyEvent e) {
					  
				    if(e.getKeyCode()==KeyEvent.VK_ENTER){
						inputText.setEditable(false);
						
						//String text = inputText.getText();
						String text = getInputText();
						
						// clean the field
						inputText.setText("");
						
						// watson
						// Send message to the assistant.
					    input = new MessageInput.Builder().text(text).build();
					    messageOptions = new MessageOptions.Builder(assistantId, sessionId)
					                                                  .input(input)
					                                                  .build();
					    response = service.message(messageOptions).execute();
						
						// set the model
						//theModel.setDialogMonitor("you: " + text + "\n");
						theModel.setInputText("you: " + text + "\n");
						
						// Print the output from dialog, if any. Assumes a single text response.
					    List<DialogRuntimeResponseGeneric> responseGeneric = response.getOutput().getGeneric();
					    if(responseGeneric.size() > 0) {
					      theModel.setInputText(response.getOutput().getGeneric().get(0).getText()+ "\n");
					    }
				    } 
				  }
			 }  
		);
		
		inputText.addKeyListener(new 
				KeyAdapter() {
				  public void keyReleased(KeyEvent e) {
					  
					  if(e.getKeyCode()==KeyEvent.VK_ENTER){
							inputText.setEditable(true);
					  }
		             
				  }
			    }  
		);
		
		
		// ------------------------------------------------------------------
		// The Watson connection
	    // Suppress log messages in stdout.
	    LogManager.getLogManager().reset();

	    // Set up Assistant service.
	    iamOptions = new IamOptions.Builder().apiKey("dbUDBQqq5HTQC3VVsMnm3AfUM87pmydXj6XnuXXLuYxZ").build();
	    service = new Assistant("2018-09-20", iamOptions);
	    assistantId = "032fd3a1-3226-419a-b260-b18e6f357401"; // replace with assistant ID

	    // Create session.
	    createSessionOptions = new CreateSessionOptions.Builder(assistantId).build();
	    session = service.createSession(createSessionOptions).execute();
	    sessionId = session.getSessionId();

		// ------------------------------------------------------------------
		//  set panel
		appPanel.add(scroll);
		appPanel.add(inputText);
		appPanel.setBackground(new Color(0,51,102));
		
		// add to frame
		frame.add(appPanel);
		
		// ------------------------------------------------------------------
		// frame
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// pack and set visible
		frame.pack();
		frame.setSize(600, 500);
		//frame.setResizable(false);
		frame.setVisible(true);
		
		// watson
		String msg="";
		// Send message to assistant.
	    input = new MessageInput.Builder().text(msg).build();
	    messageOptions = new MessageOptions.Builder(assistantId, sessionId)
	                                                  .input(input)
	                                                  .build();
	    response = service.message(messageOptions).execute();
	    
	 // Print the output from dialog, if any. Assumes a single text response.
	    List<DialogRuntimeResponseGeneric> responseGeneric = response.getOutput().getGeneric();
	    if(responseGeneric.size() > 0) {
	    	theModel.setDialogMonitor(response.getOutput().getGeneric().get(0).getText()+ "\n");
	    	setDialogMonitor(response.getOutput().getGeneric().get(0).getText()+ "\n");
	    }
	

	}
	
	// get the string from input text
	public String getInputText() {
		return inputText.getText();
	}
	
	public String getDialogMonitor() {
		return dialogMonitor.getText();
	}
	
	private void setDialogMonitor(String newDialog) {
		dialogMonitor.setText(dialogMonitor.getText() + newDialog);
		//dialogMonitor.setText(dialogMonitor.getText() + getInputText() + new);
	}

	@Override
	public void stateChanged(ChangeEvent arg0) {
		
		// read data from the model
		//String readDialogMonitor = theModel.getDialogMonitor();
		String readInputText = theModel.getInputText();
		
		// update the view
		//setDialogMonitor(in1);
		//setDialogMonitor(readDialogMonitor);
		setDialogMonitor(readInputText);
	}

	// the model instance
	NinaModel theModel;
	
	// the watson service
	private String assistantId;
	private String sessionId;
	private Assistant service;
	private IamOptions iamOptions;
	private CreateSessionOptions createSessionOptions;
	private SessionResponse session;
	
	private MessageInput input;
	private MessageOptions messageOptions;
	private MessageResponse response;

	// frame
	private JFrame frame = new JFrame("FAU - Nina Bot");

	// text area
	private JTextArea inputText = new JTextArea(1, 50);
	private JTextArea dialogMonitor = new JTextArea(20, 50);

}
