
/**
 * @author Rafael Papa
 *
 */
public class AssistantSimpleExample01 {

	public static void main(String[] args) {

	    // Suppress log messages in stdout.
	    LogManager.getLogManager().reset();

	    // Set up Assistant service.
	    IamOptions iamOptions = new IamOptions.Builder().apiKey("dbUDBQqq5HTQC3VVsMnm3AfUM87pmydXj6XnuXXLuYxZ").build();
	    Assistant service = new Assistant("2018-09-20", iamOptions);
	    String assistantId = "032fd3a1-3226-419a-b260-b18e6f357401"; // replace with assistant ID

	    // Create session.
	    CreateSessionOptions createSessionOptions = new CreateSessionOptions.Builder(assistantId).build();
	    SessionResponse session = service.createSession(createSessionOptions).execute();
	    String sessionId = session.getSessionId();

	    // Initialize with empty value to start the conversation.
	    //String currentAction="";
	    String inputText="";
	    Scanner scanner = new Scanner(System.in);
	    
		// Main input/output loop
	    do {
	      // Send message to assistant.
	      MessageInput input = new MessageInput.Builder().text(inputText).build();
	      MessageOptions messageOptions = new MessageOptions.Builder(assistantId, sessionId)
	                                                  .input(input)
	                                                  .build();
	      MessageResponse response = service.message(messageOptions).execute();

	      // If an intent was detected, print it to the console.
	      List<RuntimeIntent> responseIntents = response.getOutput().getIntents();
	      if(responseIntents.size() > 0) {
	        System.out.println("Detected intent: #" + responseIntents.get(0).getIntent());
	      }
	      
	      // If an entity was detected, print it to the console.
	      List<RuntimeEntity> responseEntities= response.getOutput().getEntities();
	      if(responseEntities.size() > 0) {
	        System.out.println("Detected Entity: #" + responseEntities.get(0).getEntity());
	      }
	      //-----------------------
	      
	      // Print the output from dialog, if any. Assumes a single text response.
	      List<DialogRuntimeResponseGeneric> responseGeneric = response.getOutput().getGeneric();
	      if(responseGeneric.size() > 0) {
	        System.out.println(response.getOutput().getGeneric().get(0).getText());
	      }

	      // Prompt for next round of input.
	      System.out.print(">> ");
	      //inputText = System.console().readLine();
	      inputText = scanner.nextLine();
	    } while(!inputText.equals("quit"));

	    scanner.close();  // rafael do a try catch later https://stackoverflow.com/questions/12519335/resource-leak-in-is-never-closed/12519343
	    // We're done, so we delete the session.
	    DeleteSessionOptions deleteSessionOptions = new DeleteSessionOptions.Builder(assistantId, sessionId).build();
	    service.deleteSession(deleteSessionOptions).execute();
	  }

}
