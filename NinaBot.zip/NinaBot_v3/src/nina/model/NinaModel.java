package nina.model;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * @author Rafael Papa and Francis Ifon
 *
 */
public class NinaModel {

	//-------------------------------------------------------------------------
    // get message from input
	public String getInputText() {
		return inputText;
	}

	public String getDialogMonitor() {
		return dialogMonitor;
	}
	
	//-------------------------------------------------------------------------
	// sets
	public void setInputText(String inputText) {
		this.inputText = inputText;
		
		ChangeEvent event = new ChangeEvent(this);
		System.out.println("debug: setInputText --> " + inputText);
		
		// observer -> notify the view
		if(listener != null)
			listener.stateChanged(event);
	}
	
	public void setDialogMonitor(String dialogMonitor) {
		this.dialogMonitor = dialogMonitor;
		
		ChangeEvent event = new ChangeEvent(this);
		System.out.println("debug: setDialogMonitor --> " + dialogMonitor);
		
		// observer -> notify the view
		if(listener != null)
			listener.stateChanged(event);
	}
		
	
	//-------------------------------------------------------------------------
	// change listener
	public void addChangeListener(ChangeListener listener) {
		this.listener = listener;
	}

	// instances
	private String inputText;
	private String dialogMonitor;
	
	// listener
	private ChangeListener listener;
}
