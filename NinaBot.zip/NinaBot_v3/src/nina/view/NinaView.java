package nina.view;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import com.ibm.watson.developer_cloud.assistant.v2.model.DialogRuntimeResponseGeneric;

import nina.model.NinaModel;
import nina.watsonservice.NinaConnection;

/**
 * @author Rafael Papa and Francis Ifon
 *
 */
public class NinaView implements ChangeListener {

	public NinaView(NinaModel theModel, NinaConnection theWatson) {
		
		this.theModel = theModel;
		this.theWatson = theWatson;

		JPanel appPanel = new JPanel();

		// decorator (add scroll to JPanel)
		JScrollPane scroll = new JScrollPane(
				dialogMonitor, 
				JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_NEVER
		);
		
		// ------------------------------------------------------------------
		// avoid the user type inside the dialog
		dialogMonitor.setEditable(false);
		dialogMonitor.setFont(new Font("Serif", Font.ITALIC, 14));
		dialogMonitor.setLineWrap(true);
		dialogMonitor.setWrapStyleWord(true);
		
		// ------------------------------------------------------------------
		// attach listeners
		// add the listener to inputText
		inputText.addKeyListener(new 
			KeyAdapter() {
				  public void keyPressed(KeyEvent e) {
					  
				    if(e.getKeyCode()==KeyEvent.VK_ENTER){
						inputText.setEditable(false);
						
						String text = getInputText();
						
						// clean the field
						inputText.setText("");
						
						theModel.setInputText("you: " + text + "\n");
						
						// send msg to Watson and get response
						List<DialogRuntimeResponseGeneric> responseGeneric = theWatson.sendMsgToWatson(text).getOutput().getGeneric();
						
						// Print the output from dialog, if any. Assumes a single text response.
					    if(responseGeneric.size() > 0) {
					    	theModel.setInputText(responseGeneric.get(0).getText()+ "\n");
					    }
				    } 
				  }
			 }  
		);
		
		// release the input text to the user
		inputText.addKeyListener(new 
				KeyAdapter() {
				  public void keyReleased(KeyEvent e) {
					  
					  if(e.getKeyCode()==KeyEvent.VK_ENTER){
							inputText.setEditable(true);
					  }
		             
				  }
			    }  
		);


		// ------------------------------------------------------------------
		// set panel
		// decorator (add scroll to JPanel)
		appPanel.add(scroll);
		appPanel.add(inputText);
		appPanel.setBackground(new Color(0,51,102));
		
		// add to frame
		frame.add(appPanel);
		
		// ------------------------------------------------------------------
		// frame
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// pack and set visible
		frame.pack();
		frame.setSize(600, 500);
		frame.setResizable(false);
		
		// launch Nina gui
		frame.setVisible(true);
		
		// send blank msg to watson to start dialog
		String msg="";

	    // send message to Watson
	    List<DialogRuntimeResponseGeneric> responseGeneric = 
	    		theWatson.sendMsgToWatson(msg).getOutput().getGeneric();
	    
	    // Print the output from dialog, if any. Assumes a single text response.
	    if(responseGeneric.size() > 0) {
	    	theModel.setDialogMonitor(responseGeneric.get(0).getText()+ "\n");
	    	setDialogMonitor(responseGeneric.get(0).getText()+ "\n");
	    }
	}
	
	// get the string from input text
	public String getInputText() {
		return inputText.getText();
	}
	
	public String getDialogMonitor() {
		return dialogMonitor.getText();
	}
	
	// set and update the dialog with the logs + new message
	private void setDialogMonitor(String newDialog) {
		dialogMonitor.setText(dialogMonitor.getText() + newDialog);
	}

	@Override
	public void stateChanged(ChangeEvent arg0) {
		
		// read data from the model
		String readInputText = theModel.getInputText();
		
		// update the view
		setDialogMonitor(readInputText);
	}

	// instances
	NinaModel theModel;
	NinaConnection theWatson;
	
	// nina gui
	private JFrame frame = new JFrame("FAU - Nina Bot");
	private JTextArea inputText = new JTextArea(1, 50);
	private JTextArea dialogMonitor = new JTextArea(20, 50);

}
