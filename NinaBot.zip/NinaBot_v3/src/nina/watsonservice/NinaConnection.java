package nina.watsonservice;
import java.util.logging.LogManager;

import com.ibm.watson.developer_cloud.assistant.v2.Assistant;
import com.ibm.watson.developer_cloud.assistant.v2.model.CreateSessionOptions;
import com.ibm.watson.developer_cloud.assistant.v2.model.MessageInput;
import com.ibm.watson.developer_cloud.assistant.v2.model.MessageOptions;
import com.ibm.watson.developer_cloud.assistant.v2.model.MessageResponse;
import com.ibm.watson.developer_cloud.assistant.v2.model.SessionResponse;
import com.ibm.watson.developer_cloud.service.security.IamOptions;


/**
 * @author Rafael Papa and Francis Ifon
 *
 */
public class NinaConnection {

	public NinaConnection() {
		// ------------------------------------------------------------------
		// The Watson connection
		// Suppress log messages in stdout.
		LogManager.getLogManager().reset();

		// Set up Assistant service.
		iamOptions = new IamOptions.Builder().apiKey("dbUDBQqq5HTQC3VVsMnm3AfUM87pmydXj6XnuXXLuYxZ").build();
		service = new Assistant("2018-09-20", iamOptions);
		assistantId = "032fd3a1-3226-419a-b260-b18e6f357401"; // replace with assistant ID

		// Create session.
		createSessionOptions = new CreateSessionOptions.Builder(assistantId).build();
		session = service.createSession(createSessionOptions).execute();
		sessionId = session.getSessionId();
	}
	
	public MessageResponse sendMsgToWatson(String msg) {
		
		input = new MessageInput.Builder().text(msg).build();
		
	    messageOptions = new MessageOptions.Builder(assistantId, sessionId)
	                                                  .input(input)
	                                                  .build();
	    
	    response = service.message(messageOptions).execute();
	    
	    return response;
	}

	// the watson service
	private String assistantId;
	private String sessionId;
	private Assistant service;
	private IamOptions iamOptions;
	private CreateSessionOptions createSessionOptions;
	private SessionResponse session;

	private MessageInput input;
	private MessageOptions messageOptions;
	private MessageResponse response;
}
