package nina.controller;
import nina.model.NinaModel;
import nina.view.NinaView;
import nina.watsonservice.NinaConnection;

/**
 * @author Rafael Papa and Francis Ifon
 *
 */

public class NinaBot {

	public static void main(String[] args) {
		
		NinaModel theModel = new NinaModel();
		NinaConnection theWatson = new NinaConnection();
		NinaView theView = new NinaView(theModel, theWatson);

		// attach the bot view as a listener
		theModel.addChangeListener(theView);
	}
}